#include <stdio.h>

void angkasial(int a, int b)
{
    // int a,b;
    // printf("Angka a %d",a);
    // printf("Angka b %d",b);
    int X = 0;
    for (int i = a; i <= b; ++i)
    {
        if (i % 10 == 5 || i % 10 == 6 || i == 15 || i == 6)
        {
            X++;
        }
    }
    printf("Jumlah kamar yang harus dihindari: %d\n", X);
}
int main(){
    int a,b;
        printf("Masukkan bilangan pertama : ");
                scanf("%d", &a);
                printf("Masukkan bilangan kedua : ");
                scanf("%d", &b);
                angkasial(a, b);
    return 0;
}