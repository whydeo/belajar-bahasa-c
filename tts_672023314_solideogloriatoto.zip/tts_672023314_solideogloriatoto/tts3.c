#include <stdio.h>

void statistika(int c)
{
    // printf("tes:%d",c);
    int kecil, gede, d;
    printf("masukan angka sebanyak %d kali:", c);
    kecil = gede = c;
    for (int i = 0; i < c; i++)
    {
        scanf("%d", &d);
        if (d < kecil)
        {
            kecil = d;
        }
        if (d > gede)
        {
            gede = d;
        }
    }
    printf("angka terkecil :%d \n", kecil);
    printf("angka terbesar :%d \n", gede);
}
int main()
{
    int c;
    printf("masukan satu angka:");
    scanf("%d", &c);
    statistika(c);
    return 0;
}